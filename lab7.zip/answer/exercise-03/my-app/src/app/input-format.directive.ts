import { Directive, HostListener, ElementRef } from '@angular/core';

@Directive({
  selector: '[customInputFormat]',
  standalone: true,
})
export class InputFormatDirective {
  constructor(private elementRef: ElementRef) {}

  @HostListener('blur') onBlur() {
    const inputValue: string = this.elementRef.nativeElement.value;
    if (inputValue) {
      this.elementRef.nativeElement.value = inputValue.toUpperCase();
    }
  }
}
